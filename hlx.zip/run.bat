echo off

echo Hello from HLX!

start notepad.exe